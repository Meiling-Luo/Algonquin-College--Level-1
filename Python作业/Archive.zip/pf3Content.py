worldCup = {
    "A":["Ecuador","Netherlands","Qatar","Senegal"],
    "B":["England","Iran","USA","Wales"],
    "C":["Argentina","Mexico","Poland","Saudi Arabia"],
    "D":["Australia","Denmark","France","Tunisia"],
    "E":["Costa Rica","Germany","Japan","Spain"],
    "F":["Belgium","Canada","Croatia","Mrocco"],
    "G":["Brazil","Cameroon","Serbia","Switzerland"],
    "H":["Ghana","Portugal","Korea Republic","Uruguay"],
}

#Format of the list stored in countryResult
#[Number of matches played, Number of Wins, Number of Draws, Number of Losses, Number of goals scored, Number of goals conceded, Goal Difference, Number of points]
#In short
#[MP,W,D,L,GF,GA,GD=GF-GA,Pts]
countryResult = {
    "Ecuador":[0,0,0,0,0,0,0,0],
    "Netherlands":[0,0,0,0,0,0,0,0],
    "Qatar":[0,0,0,0,0,0,0,0],
    "Senegal":[0,0,0,0,0,0,0,0],
    "England":[0,0,0,0,0,0,0,0],
    "Iran":[0,0,0,0,0,0,0,0],
    "USA":[0,0,0,0,0,0,0,0],
    "Wales":[0,0,0,0,0,0,0,0],
    "Argentina":[0,0,0,0,0,0,0,0],
    "Mexico":[0,0,0,0,0,0,0,0],
    "Poland":[0,0,0,0,0,0,0,0],
    "Saudi Arabia":[0,0,0,0,0,0,0,0],
    "Australia":[0,0,0,0,0,0,0,0],
    "Denmark":[0,0,0,0,0,0,0,0],
    "France":[0,0,0,0,0,0,0,0],
    "Tunisia":[0,0,0,0,0,0,0,0],
    "Costa Rica":[0,0,0,0,0,0,0,0],
    "Germany":[0,0,0,0,0,0,0,0],
    "Japan":[0,0,0,0,0,0,0,0],
    "Spain":[0,0,0,0,0,0,0,0],
    "Belgium":[0,0,0,0,0,0,0,0],
    "Canada":[0,0,0,0,0,0,0,0],
    "Croatia":[0,0,0,0,0,0,0,0],
    "Morocco":[0,0,0,0,0,0,0,0],
    "Brazil":[0,0,0,0,0,0,0,0],
    "Cameroon":[0,0,0,0,0,0,0,0],
    "Serbia":[0,0,0,0,0,0,0,0],
    "Switzerland":[0,0,0,0,0,0,0,0],
    "Ghana":[0,0,0,0,0,0,0,0],
    "Portugal":[0,0,0,0,0,0,0,0],
    "Korea Republic":[0,0,0,0,0,0,0,0],
    "Uruguay":[0,0,0,0,0,0,0,0],
}

#What is a python statement that prints Canada on the screen (use the dictionary worldCup)

#What is a python statement that prints the number of goals scored by Canada (use the dictionary countryResult)

#What is a python statement that prints the number of points of Canada (use the dictionary worldCup)

#What is a python statement that sets the Goal difference for Brazil (use the dictionary countryResult)

#What is a python statement that fixes the typo in group F, replacing Mrocco with Morocco (use the dictionary worldCup)

#Write the code of the function printGroup
#This function creates and returns a string which is the  html table that displays the group name and each member of the group groupName
#if groupName is not a valid group, an error message is displayed
#
#Example string returned if groupName="A":<table><tr><th>Group A</th></tr><tr><td>Ecuador</td></tr><tr><td>Netherlands</td></tr><tr><td>Qatar</td></tr><tr><td>Senegal</td></tr></table>
def printGroup(groupName):
    return strHtml

#Write the code of the function testPrintGroup
#This function tests the function printGroup:
# - prompts the user for a group name
# - calls the function to create the html string
# - Saves the string into a file groupName.html where groupName is the group name: A to G
# - function starts again until the user presses "0"
def testPrintGroup():
    pass

#Write the code of the function postGame
#
#Note that knowing the function signature, you may start doing the next function and come back to this one later
#
#This function receives the result of the game as a string with the following format
#Group, Country1: GoalsScored, Country2: GoalsScored
#Example:
#F,Belgium:1,Canada:0
# the function parses the input (hint: use split)
# then updates the dictionary dResult
#[Number of matches played, Number of Wins, Number of Draws, Number of Losses, Number of goals scored, Number of goals conceded, Goal Difference, Number of points]
#
#As an example if gameResult is "F,Belgium:1,Canada:0"
#For Canada:
#   Number of matches played  is incremented by 1
#   Number of goals conceded is incremented by 1
#   Number of Losses is incremented by 1
#
#For Belgium:
#   Number of matches played is incremented by 1
#   Number of goals scored is incremented by 1
#   Number of Wins is incremented by 1
#   Points is incremented by 3
#
def postGame(strGameResult,dResult):
    #convert strGameResult to a list using split

    #Extract the first country name and number of goals scored using split

    # Extract the second country name and number of goals scored using split

    # then updates the dictionary dResult
    # [Number of matches played, Number of Wins, Number of Draws, Number of Losses, Number of goals scored, Number of goals conceded, Goal Difference, Number of points]
    # [Mp,W,D,L,GF,GA,GD,Pts]
    #if first country wins
    #update dResult with appropriate values:
    #first country: W +=1 GF+=s1 GA+=s2 Pts+=3 Mp+=1 GD+=s1-s2
    #second country: L+=1 GF+=s2 GA+=s1 Mp+=1 GD+=s1-s2





    #if second country wins
    #update dResult with appropriate values:
    #first country: l+=1 GF+=s1 GA+=s2  MP+=1 GD+=s1-s2
    #second country: w+=1 GF+=s2 GA+=s1 MP+=1 GD+=s1-s2 pts+=3




    #if draw
    #update dResult with appropriate values:
    #first country d+=1 GF+=s1 GA+=s2  MP+=1 GD+=s1-s2 pts+=1
    #second country: d+=1 GF+=s2 GA+=s1 MP+=1 GD+=s1-s2 pts+=1




    return

#Write the code of the function readFileResults
#This function receives the file with game results
#It then populates the dictionary dResult
#This function makes use of the postGame function created previously
def readFileResults(fileName,dResult):
    return

#Write the code of the function printCountryResults
#This function prints on the screen a html table row that contains
#the current results of the country strCountry
#In order the table row displays:
#Match played | Wins | Losses | Draws | Goals For | Goals Against | Goals differential | Points
#
#Example output on screen
#<tr><td>1/td><td>1/td><td>0/td><td>0/td><td>1/td><td>0/td><td>1/td><td>3/td></tr>
def printCountryResults(strCountry,dResult)
    pass

#Write the code of the function printGroupResults
#This function prints on screen a html table that displays the results
#of all the countries in the group.
#It makes calls to the function printCountryResults
def printGroupResults(strGroup,dResult,dGroup)
    pass

#This code should work without any modification
printGroup("A")
readFileResults("results.txt",countryResult)
printCountryResults("Canada",countryResult["Canada"])
printGroupResults("F",countryResult,worldCup)



