# Lab 3

Unless you did some programming before, do not attempt to write the code before the lecture.

1. Create a new project in Pycharm called Lab3
2. Click on the `terminal` tab and use `pip` to install the `pylightxl` module
3. Download the 2 files `lab3.py` and `cities.xlsx` from Github
4. Add the 2 files to your project
5. Add the file `stats.py` (from last week) to your project (for reference puposes)
6. Starting line 8 in `lab3.py` write the python statements to perform the task explained as a comment

The file `stats.py` will provide some good code snippets to perform some of the tasks of Lab 3.

Once finished, commit the file `lab3.py` to GitHub.
